import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import SurveySubmitContainer from '../containers/SurveySubmitContainer';

const SurveySubmitPage = () => {
    return (
        <>
            <Header />
                <SurveySubmitContainer />
            <Footer />
        </>
    );
};

export default SurveySubmitPage;