import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import MainContainer from '../containers/MainContainer';

const MainPage = () => {
    return (
        <>
            <Header />
                <MainContainer />
            <Footer />
        </>
    );
};

export default MainPage;