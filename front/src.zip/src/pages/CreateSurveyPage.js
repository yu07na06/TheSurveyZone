import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import CreateSurveyContainer from '../containers/CreateSurveyContainer';

const CreateSurveyPage = () => {
    return (
        <>
            <Header />
                <CreateSurveyContainer />
            <Footer />
        </>
    );
};

export default CreateSurveyPage;