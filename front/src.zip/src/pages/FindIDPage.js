import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import FindIDContainer from '../containers/FindIDContainer';

const FindIDPage = () => {
    return (
        <>
            <Header />
                <FindIDContainer />
            <Footer />
        </>
    );
};

export default FindIDPage;