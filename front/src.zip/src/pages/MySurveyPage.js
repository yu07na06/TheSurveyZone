import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import MySurveyContainer from '../containers/MySurveyContainer';

const MySurveyPage = () => {
    return (
        <>
            <Header />
                <MySurveyContainer />
            <Footer />
        </>
    );
};

export default MySurveyPage;