import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import RegisterContainer from '../containers/RegisterContainer';

const ResultPage = () => {
    return (
        <>
            <Header />
                <RegisterContainer />
            <Footer />
        </>
    );
};

export default ResultPage;