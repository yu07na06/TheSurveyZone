import React from 'react';
import Footer from '../components/Footer/Footer';
import Header from '../components/Header/Header';
import LoginContainer from '../containers/LoginContainer';

const LoginPage = () => {
    return (
        <>
            <Header />
                <LoginContainer />
            <Footer />
        </>
    );
};

export default LoginPage;