import React from 'react';

const MainSurvey = () => {
    return (
        <>
          MainSurvey hi  
        </>
    );
};

export default MainSurvey;