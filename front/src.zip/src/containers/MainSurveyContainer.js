import React from 'react';
import MainSurvey from '../components/MainSurvey';

const MainSurveyContainer = () => {
    return (
        <>
            <MainSurvey />
        </>
    );
};

export default MainSurveyContainer;