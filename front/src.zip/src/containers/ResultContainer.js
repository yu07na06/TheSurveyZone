import React from 'react';
import Result from '../components/Result';

const ResultContainer = () => {
    return (
        <>
            <Result />
        </>
    );
};

export default ResultContainer;