import React from 'react';
import MySurvey from '../components/MySurvey';

const MySurveyContainer = () => {
    return (
        <>
            <MySurvey />
        </>
    );
};

export default MySurveyContainer;