import React from 'react';
import FindPW from '../components/FindPW';
import { createTheme  } from '@mui/material/styles';

const FindPWContainer = () => {
    const theme = createTheme();

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        console.log({
          email: data.get('email'),
          password: data.get('password'),
        });
      };

    return (
        <>
            <FindPW 
                handleSubmit={handleSubmit}
                theme={theme}
            />   
        </>
    );
};

export default FindPWContainer;