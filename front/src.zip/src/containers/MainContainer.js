import React from 'react';
import Main from '../components/Main';

const MainContainer = () => {
    return (
        <>
            <Main />   
        </>
    );
};

export default MainContainer;