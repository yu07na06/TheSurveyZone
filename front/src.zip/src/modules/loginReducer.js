import { handleActions } from "redux-actions";

const initialState = {
    a:"6516541",
};

const loginReducer = handleActions({

}, initialState);

export default loginReducer;