import { handleActions } from "redux-actions";

const initialState = {

};

const submitReducer = handleActions({

}, initialState);

export default submitReducer;