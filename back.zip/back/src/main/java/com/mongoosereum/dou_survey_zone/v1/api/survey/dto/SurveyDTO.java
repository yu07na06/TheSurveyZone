package com.mongoosereum.dou_survey_zone.v1.api.survey.dto;

public class SurveyDTO {
}