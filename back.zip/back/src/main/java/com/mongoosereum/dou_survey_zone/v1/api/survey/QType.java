package com.mongoosereum.dou_survey_zone.v1.api.survey;

public enum QType {
    MULTIPLE,
    SHORT_ANSWER,
    ESSAY
}
