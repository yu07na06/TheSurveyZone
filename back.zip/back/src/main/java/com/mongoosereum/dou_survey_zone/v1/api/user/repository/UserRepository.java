package com.mongoosereum.dou_survey_zone.v1.api.user.repository;

import com.mongoosereum.dou_survey_zone.v1.api.user.dto.UserDTO;

import java.util.List;

public interface UserRepository {

    List<UserDTO> findBoardAll();

}
