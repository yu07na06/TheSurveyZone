package com.mongoosereum.dou_survey_zone.v1.api.tag.dao;

public class TagDAO {
}
