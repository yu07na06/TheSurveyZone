package com.mongoosereum.dou_survey_zone.v1.api.survey.dao;

public class SurveyDAO {
}
