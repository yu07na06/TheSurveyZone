package com.mongoosereum.dou_survey_zone.v1.api.tag.dto;

public class TagDTO {
}
