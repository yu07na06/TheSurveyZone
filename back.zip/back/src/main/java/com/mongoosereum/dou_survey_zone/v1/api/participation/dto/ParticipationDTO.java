package com.mongoosereum.dou_survey_zone.v1.api.participation.dto;

public class ParticipationDTO {
}
