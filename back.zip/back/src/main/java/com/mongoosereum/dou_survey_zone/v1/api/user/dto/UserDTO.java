package com.mongoosereum.dou_survey_zone.v1.api.user.dto;

import lombok.Data;

@Data
public class UserDTO {

    private String user_Email;
    private String user_Password;
    private String user_Name;
    private String user_Tel;


}
