package com.mongoosereum.dou_survey_zone.v1.api.controller;

import com.mongoosereum.dou_survey_zone.v1.api.user.dao.UserDAO;
import com.mongoosereum.dou_survey_zone.v1.api.user.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/v1/user", produces = MediaType.APPLICATION_JSON_VALUE)
public class UserController{

    @Autowired
    private UserDAO Dao;

    @GetMapping(path="/ddd")
    public String findUser(UserDTO userDTO) {

        System.out.println("============유저 찾기=========");
        List<UserDTO> result = Dao.findBoardAll();
        System.out.println(result);

        return "success";
    }

    // 218.154.207.223:8080/api/v1/user/test
    @PreAuthorize("isAuthenticated()")
    @PostMapping(path="/test")
    public String greeting(@RequestBody UserDTO userDTO) {

        System.out.println(userDTO.getUser_Email());
        System.out.println(userDTO.getUser_Password());

        return "success";
    }
}