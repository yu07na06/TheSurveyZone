package com.mongoosereum.dou_survey_zone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DouSurveyZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
